<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#8d8e90" style="font-family: verdana,courier;" >
	<td>
		<table width="800" border="0" cellspacing="0" cellpadding="0" bgcolor="white" align="center">
			<tr style="background-color: grey;line-height: 5px;">
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td>
					<br>
					&nbsp;&nbsp;&nbsp;
					<span style="font-weight: bold; font-size: 22px;">
						Carbon38: New Order #
					</span>
					<br>
					<br>
					&nbsp;&nbsp;&nbsp;
					<span style="font-weight: bold; font-size: 20px;">
					100810789 </span> Inbox
				</span>
				<br>
				<br>
				<center>
			<img src="http://tee.ots.co.th/img/carbon38-5.png" /></td>
			<!-- <img src="./img/carbon38-5.png" /></td> -->
			<br>
		</td>
	</tr>
	
	<tr>
		<td><center>
			<br>
			&nbsp;&nbsp;&nbsp;
			<span style="font-weight: bold; font-size: 30px;letter-spacing: 15px;">
				CONGRATS!
			</span>
			<br>
		</td>
	</tr>
	<tr>
		<td><center>
			<br>
			&nbsp;&nbsp;&nbsp;
			Your order is confirmed. You just invested in yourself
			<br>
			&nbsp;&nbsp;&nbsp;
			while supporting female-led brands.
			<br>
		</td>
	</tr>
	<tr>
		<td><center>
			<br>
			&nbsp;&nbsp;&nbsp;
			Whoa! The response to our sale has been hugs. Don't worry,
			<br>
			&nbsp;&nbsp;&nbsp;
			our shipping team is hustling to get your order to you ASAP.
			<br>
			&nbsp;&nbsp;&nbsp;
			We'll send you another email once your order is ready-to-go!
			<br>
		</td>
	</tr>
	<tr>
		<td><center>
			<br>
			&nbsp;&nbsp;&nbsp;
			<span style="font-weight: bold; font-size: 16px;">
				ORDER # 100810789
			</span>
			<br>
			&nbsp;&nbsp;&nbsp;
			<span style="font-weight: bold; font-size: 12px;">
				ORDER DATE: FEB 19, 2020
			</span>
			<br>
		</td>
	</tr>
	<tr>
		<td><center>
			<br>
			<a href="https://sossenseofstyle.com/" target="_blank" style=" text-decoration: none;">
				<div style="background-color:black;width: 15%;margin-left: 3%;text-align: center;padding: 1%;cursor: pointer;color: white;font-size: 14px;">VIEW ORDER</div>
			</a>
		</tr>
		<tr>
			<td><center>
				<br>
				&nbsp;&nbsp;&nbsp;
				<span style="font-weight: bold; font-size: 14px;">
					SHIPPING ADDRESS
				</span>
				<br>
				&nbsp;&nbsp;&nbsp;
				<span style="font-weight: bold; font-size: 14px;">
					Sunee Sookwongse
				</span>
				<br>
				&nbsp;&nbsp;&nbsp;
				8200 Dracaena Drive
				<br>
				&nbsp;&nbsp;&nbsp;
				Buena Park, CA 90620 United States
				<br>
				&nbsp;&nbsp;&nbsp;
				T: 17147615482
				<br>
				<br>
			</td>
		</tr>
		<tr>
			<td><center>
				<div style="font-size: 14px;">
					<div style="border-bottom: 2px solid black;width: 50%;"></div>
					<br>
					&nbsp;&nbsp;&nbsp;
					<span style="font-weight: bold; font-size: 12px;">
						YOUR CHECKOUT LOOKED REALLY GOOD...
					</span>
					<br>
					<br>
				</div></td>
			</tr>
			<tr style="background-color: grey;line-height: 5px;">
				<td>&nbsp;</td>
			</tr>
		</table>
	</td>
	<tr>
		<td>&nbsp;</td>
	</tr>
</table>