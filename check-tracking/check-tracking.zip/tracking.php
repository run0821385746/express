<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<?php require('inc_header.php'); ?>
	<?php require('inc/conndb.php'); ?>
</head>
<body>

<div class="row">
  <div class="col-md-12" style="">
    <div id="spinner_frame" 
    style="display: none;
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        -webkit-transform: translate(-50%, -50%);
        -moz-transform: translate(-50%, -50%);
        -o-transform: translate(-50%, -50%);
        -ms-transform: translate(-50%, -50%);
        z-index: 100;
    "><p align="center">
        <img src="./images/preloader_big.gif">
    </p></div>
  </div>
</div>

    <div class="thetop"></div>
    <?php require('inc_topmenu.php'); ?>
    
    <!--------------- T R A C K I N G --------------->
    <div class="BlueBG">
        <div class="container-fluid">
            <div class="wrap-pad">
                <div class="row">
                    <div class="col">
                        <div class="header-subtopic mb-4">
                            <h1>ตรวจสอบสถานะ</h1>
                            <h4>ติดตามพัสดุของคุณได้ทุกที่ ทุกเวลา</h4>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="icon-circle"><img src="images/icon-tracking.png"></div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6 col-md-8 col-12 offset-lg-3 offset-md-2">
                        <div class="trackBox">
                            <div class="input-group">
                                <input type="text" id="tracking_no" class="form-control" placeholder="หมายเลขพัสดุ" >
                                <div class="input-group-append">
                                    <button class="btn btn-outline-secondary btnCheck " type="button" id="button-addon2">ตรวจสอบ<i class="fas fa-search"></i></button>
                                </div>
                            </div>
                        </div>
                            
                    </div>
                </div>
            </div>
        </div>
    </div>
    

    <div class="content-padding more-padding show_result " style="display: none;">
        <div class="container-fluid">
            <div class="wrap-pad">
<!-- 

1.นำส่งเรียบร้อย  => images/icon-check.png
2.พัสดุติดปัญหา  => images/icon-exclamation.png
3.ติดต่อผู้รับไม่ได้ => images/icon-exclamation.png
4.นำส่งพัสดุ  => images/icon-time.png
5.จ่ายพัสดุ  => images/icon-time.png
6.พัสดุติดปัญหา => images/icon-exclamation.png
7.สินค้าค้างส่ง => images/icon-exclamation.png
8.สาขาปลายทางรับพัสดุแล้ว => images/icon-time.png
9.อยู่ระหว่างขนส่ง  => images/icon-time.png
10.รับพัสดุเข้าระบบ => images/icon-product.png

	<li>
	<ul class="date">
	<li class="rs_date">วันที่ 12 พ.ค. 2563</li>
	<li class="rs_time">เวลา 12.00</li>
	</ul>
	<div class="status-img rs_status_img"><img src="images/icon-check.png"></div>
	<ul class="status">
	<li class="rs_cause_01">นำส่งเรียบร้อย</li>
	<li class="rs_cause_02">ผู้รับ อัฐฌา สมพรกิจกุล</li>
	</ul>
	</li>

1.นำส่งเรียบร้อย  => images/icon-check.png
Success		ความสำเร็จ

9.อยู่ระหว่างขนส่ง  => images/icon-time.png
TransferToDropCenter	โอนไปยัง DropCenter

9.อยู่ระหว่างขนส่ง  => images/icon-time.png
TransferToCourier		โอนไปยังจัดส่ง


 -->
            	<div class="row">
                    <div class="col">
                        <h3 style="color: blue;" >หมายเลขพัสดุ : <span id="rs_tracking_no"></span></h3>
                    </div>
                </div>


 <div class="content-padding show_track " style="display: none;">

       <!--          <div class="row">
                    <div class="col">
                        <h3>หมายเลขพัสดุ : <span>SEV160563000001</span></h3>
                    </div>
                </div> -->

                <div class="row">
                    <div class="col">
                        <ul class="tracking-status">

                        	<li>
                                <ul class="date">
                                    <li class="rs_date">วันที่ 12 พ.ค. 2563</li>
                                    <li class="rs_time">เวลา 12.00</li>
                                </ul>
                                <div class="status-img"><img class="rs_status_img" src=""></div>
                                <ul class="status">
                                    <li class="rs_cause_01"></li>
                                    <li class="rs_cause_02"></li>
                                </ul>
                            </li>

                        	<!--
                            <li>
                                <ul class="date">
                                    <li class="rs_date">วันที่ 12 พ.ค. 2563</li>
                                    <li class="rs_time">เวลา 12.00</li>
                                </ul>
                                <div class="status-img rs_status_img"><img src="images/icon-check.png"></div>
                                <ul class="status">
                                    <li class="rs_cause_01">นำส่งเรียบร้อย</li>
                                    <li class="rs_cause_02">ผู้รับ อัฐฌา สมพรกิจกุล</li>
                                </ul>
                            </li>

                            <li>
                                <ul class="date">
                                    <li>วันที่ 11 พ.ค. 2563</li>
                                    <li>เวลา 14.00</li>
                                </ul>
                                <div class="status-img"><img src="images/icon-exclamation.png"></div>
                                <ul class="status">
                                    <li>พัสดุติดปัญหา</li>
                                    <li>ติดต่อผู้รับไม่ได้</li>
                                </ul>
                            </li>
                            <li>
                                <ul class="date">
                                    <li>วันที่ 11 พ.ค. 2563</li>
                                    <li>เวลา 09.30</li>
                                </ul>
                                <div class="status-img"><img src="images/icon-time.png"></div>
                                <ul class="status oneLine">
                                    <li>นำส่งพัสดุ</li>
                                </ul>
                            </li>
                            <li>
                                <ul class="date">
                                    <li>วันที่ 11 พ.ค. 2563</li>
                                    <li>เวลา 08.30</li>
                                </ul>
                                <div class="status-img"><img src="images/icon-time.png"></div>
                                <ul class="status oneLine">
                                    <li>จ่ายพัสดุ</li>
                                </ul>
                            </li>
                            <li>
                                <ul class="date">
                                    <li>วันที่ 10 พ.ค. 2563</li>
                                    <li>เวลา 17.00</li>
                                </ul>
                                <div class="status-img"><img src="images/icon-exclamation.png"></div>
                                <ul class="status">
                                    <li>พัสดุติดปัญหา</li>
                                    <li>สินค้าค้างส่ง</li>
                                </ul>
                            </li>
                            <li>
                                <ul class="date">
                                    <li>วันที่ 8 พ.ค. 2563</li>
                                    <li>เวลา 08.30</li>
                                </ul>
                                <div class="status-img"><img src="images/icon-time.png"></div>
                                <ul class="status">
                                    <li>สาขาปลายทางรับพัสดุแล้ว</li>
                                    <li>บ้านโป่ง - ราชบุรี</li>
                                </ul>
                            </li>
                            <li>
                                <ul class="date">
                                    <li>วันที่ 7 พ.ค. 2563</li>
                                    <li>เวลา 15.30</li>
                                </ul>
                                <div class="status-img"><img src="images/icon-time.png"></div>
                                <ul class="status oneLine">
                                    <li>อยู่ระหว่างขนส่ง</li>
                                </ul>
                            </li>
                            <li>
                                <ul class="date">
                                    <li>วันที่ 7 พ.ค. 2563</li>
                                    <li>เวลา 10.00</li>
                                </ul>
                                <div class="status-img"><img src="images/icon-product.png"></div>
                                <ul class="status">
                                    <li>รับพัสดุเข้าระบบ</li>
                                    <li>สามพราน - นครปฐม</li>
                                </ul>
                            </li> -->
                        </ul>
                              
                    </div>
                </div>
                
                </div>
                        
            </div>
        </div>
    </div>
    
    <?php include('inc_topbutton.php'); ?>
    <?php require('inc_footer.php'); ?>
</body>
</html>


    <script type="text/javascript">
		$(document).ready(function () {
			$(".btnCheck").click(function(event) {

				var tracking_no = $("#tracking_no").val();
				if(tracking_no==""){
					$("#tracking_no").focus();
					return false;
				}else{

					$("#spinner_frame").show();

						// alert(tracking_no);
				        $.ajax({
				            type: "POST",
				            url: "inc/get_data.php",
				            dataType: 'json',
				            data: { tracking_no:tracking_no },
				            success: function(data){
				            	console.log(data);
				            	if(data==""){

				            		setTimeout(function(){
				            			$(".show_result").show();
										$("#rs_tracking_no").html("<font color=red> == ไม่พบข้อมูล หมายเลขพัสดุ ที่ระบุ ==</font>");
				            			$("#spinner_frame").hide();
				            			$(".show_track").hide();
									}, 500);  
				            		
				            	}else{

				            		setTimeout(function(){
				            			$(".show_result").show();
										$.each(data, function( index, value ) {
							                $("#rs_tracking_no").html(value.tracking_no);
							                $(".rs_status_img").attr("src", value.rs_status_img);
							                $(".rs_cause_01").html(value.rs_cause_01);
							                $(".rs_cause_02").html(value.receiver);
							                $(".rs_date").html(value.rs_date);
							                $(".rs_time").html(value.rs_time);
							                $("#spinner_frame").hide();
							                $(".show_track").show();
							            });
									}, 1500); 

				            	}
				                
				            }
						});
				}

			});
		});
	</script>